export class SumDto {
  key: string;
  numbers: number[];
}
