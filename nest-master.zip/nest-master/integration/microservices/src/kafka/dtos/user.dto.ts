export class UserDto {
  name: string;
  email: string;
  phone: string;
  years: number;
}
