export declare class AppModule {}
