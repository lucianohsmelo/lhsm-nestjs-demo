The common package comes with decorators such as `@Controller()`, `@Injectable()` and so on.
