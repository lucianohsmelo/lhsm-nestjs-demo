/**
 * @publicApi
 */
export enum VersioningType {
  URI,
  HEADER,
  MEDIA_TYPE,
  CUSTOM,
}
